CREATE TABLE IF NOT EXISTS `welcome_pop_up_box` (
  `intid` int(11) NOT NULL AUTO_INCREMENT,
  `vartext` text NOT NULL,
  PRIMARY KEY (`intid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

